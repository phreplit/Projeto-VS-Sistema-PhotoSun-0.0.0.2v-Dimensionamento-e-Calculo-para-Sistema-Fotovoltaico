﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // chama metodo limpar
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();
            textBox17.Clear();
            textBox18.Clear();
            textBox19.Clear();
            textBox20.Clear();
            textBox21.Clear();
            textBox22.Clear();

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
                + "\nPara converter volts em watts multiplicamos os volts por 10."
                + "\nPara converter watts em volts dividimos os watts por 10."
                + "\nPara calcular a potencia dos modulos fazemos a multiplicacao da potencia nominal do modulo vezes a quantidade de modulos."
                + "\nPara calcular a geracao semanal utilizamos o calculo (potencia dos modulos)x(horas por dia)x(dias por semana)."
                + "\nPara calcular a geracao mensal utilizamos o calculo (potencia dos modulos)x(horas por dia)x(dias por mes)."
                + "\nPara calcular a geracao anual utilizamos o calculo (potencia dos modulos)x(horas por dia)x(dias por ano)."
                + "\nPara calcular e dimensionar a quantidade de modulos que compoe um painel solar utilizamos o seguinte calculo:"
                + "\nPotencia calculada do sistema (Pfv) em watts dividido pela Potencia nominal do modulo em watts = a Quantidade de Modulos."
                + "\nPara converter 1kwh para 1wh basta fazer o calculo ex: 73kwh para wh sera 73000wh. Então será 1kwh = 1000wh.");

        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.Text = "Sobre";
            MessageBox.Show("Sobre\n" + "\nSoftware: Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico \n" + "\nAuthor: PHNO" + "\nData Release: 04/09/2024" + "\nVersao Codigo: 0.0.0.2v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1))
            {
                int numero2 = 10;
                int mult = numero1 * numero2;

                textBox2.Text = ("" + mult);
            }
            else // se não faz calculo, então emite erro.
            {
                textBox2.Text = "Erro. digite um numero.";
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox3.Text, out int numero3))
            {
                int numero4 = 10;
                int div = numero3 / numero4;

                textBox4.Text = ("" + div);
            }
            else
            {
                textBox4.Text = "Erro. digite um numero.";
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox5.Text, out int numero5) && int.TryParse(textBox6.Text, out int numero6))
            {
                int mult2 = numero5 * numero6;

                textBox7.Text = ("" + mult2);
            }
            else
            {
                textBox7.Text = "Erro. digite um numero.";
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox8.Text, out int numero7) && int.TryParse(textBox9.Text, out int numero8) && int.TryParse(textBox10.Text, out int numero9))
            {
                int numero10 = 1000;
                int mult3 = numero7 * numero8 * numero9;
                int result = mult3 / numero10;

                textBox11.Text = ("" + result);
            }
            else
            {
                textBox11.Text = "Erro. digite um numero.";
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox12.Text, out int numero11) && int.TryParse(textBox13.Text, out int numero12) && int.TryParse(textBox14.Text, out int numero13))
            {
                int numero14 = 1000;
                int mult4 = numero11 * numero12 * numero13;
                int result2 = mult4 / numero14;

                textBox15.Text = ("" + result2);
            }
            else
            {
                textBox15.Text = "Erro. digite um numero.";
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox16.Text, out int numero15) && int.TryParse(textBox17.Text, out int numero16) && int.TryParse(textBox18.Text, out int numero17))
            {
                int numero18 = 1000;
                int mult5 = numero15 * numero16 * numero17;
                int result3 = mult5 / numero18;

                textBox19.Text = ("" + result3);
            }
            else
            {
                textBox19.Text = "Erro. digite um numero.";
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox20.Text, out int numero19) && int.TryParse(textBox21.Text, out int numero20))
            {
                int div2 = numero19 / numero20;

                textBox22.Text = ("" + div2);
            }
            else
            {
                textBox22.Text = "Erro. digite um numero.";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox1.Clear();
                textBox2.Clear();
            }
            else // se não faz calculo, então emite erro.
            {
                textBox2.Text = "Erro. nada para apagar.";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox3.Text, out int numero3))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox3.Clear();
                textBox4.Clear();
            }
            else
            {
                textBox4.Text = "Erro. nada para apagar.";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox5.Text, out int numero5) && int.TryParse(textBox6.Text, out int numero6))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
            }
            else
            {
                textBox7.Text = "Erro. nada para apagar.";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox8.Text, out int numero7) && int.TryParse(textBox9.Text, out int numero8) && int.TryParse(textBox10.Text, out int numero9))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
            }
            else
            {
                textBox11.Text = "Erro. nada para apagar.";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox12.Text, out int numero11) && int.TryParse(textBox13.Text, out int numero12) && int.TryParse(textBox14.Text, out int numero13))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox12.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox15.Clear();
            }
            else
            {
                textBox15.Text = "Erro. nada para apagar.";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox16.Text, out int numero15) && int.TryParse(textBox17.Text, out int numero16) && int.TryParse(textBox18.Text, out int numero17))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox16.Clear();
                textBox17.Clear();
                textBox18.Clear();
                textBox19.Clear();
            }
            else
            {
                textBox19.Text = "Erro. nada para apagar.";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox20.Text, out int numero19) && int.TryParse(textBox21.Text, out int numero20))
            {
                this.Text = "Sistema - PhotoSun 0.0.0.2 - Dimensionamento e Calculo para Sistema Fotovoltaico";
                textBox20.Clear();
                textBox21.Clear();
                textBox22.Clear();
            }
            else
            {
                textBox22.Text = "Erro. nada para apagar.";
            }
        }
    }
}
